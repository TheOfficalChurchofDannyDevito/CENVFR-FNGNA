// C++ program to illustrate for loop
#include <iostream>
using namespace std;

int main()
{
	for (int i = 6; i <= 666; i++)
	{
		cout << "mFNGNA JVYY SBTVIR LBHm\n";
	}

	return 0;
}
